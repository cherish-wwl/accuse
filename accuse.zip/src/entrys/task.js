
import App from '../page/task'

import {init } from '../main';

init(App)