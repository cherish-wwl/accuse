
import Feedback from '../page/feedback'
import {init } from '../main';

init(Feedback)