
import App from '../page/myFeedback'

import {init } from '../main';

init(App)