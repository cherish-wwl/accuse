
import App from '../page/coinDetail'

import {init } from '../main';

init(App)