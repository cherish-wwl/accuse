
import App from '../page/report'

import {init } from '../main';

init(App)